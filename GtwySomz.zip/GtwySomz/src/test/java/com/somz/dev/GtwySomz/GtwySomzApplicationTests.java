package com.somz.dev.GtwySomz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GtwySomzApplicationTests {

	@Test
	void contextLoads() {
	}

}
