package com.somz.dev.GtwySomz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GtwySomzApplication {

	public static void main(String[] args) {
		SpringApplication.run(GtwySomzApplication.class, args);
	}

}
